/*
import React, { useEffect, useState } from 'react';
import { Text, View, Button, Alert } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Location from 'expo-location';
import * as BackgroundFetch from 'expo-background-fetch';
import * as TaskManager from 'expo-task-manager';

// Definisci il nome del task per il background fetch
const BACKGROUND_FETCH_TASK = 'background-fetch-task';

// Configura le notifiche
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

// Definisci il task di background fetch
TaskManager.defineTask(BACKGROUND_FETCH_TASK, async () => {
  try {
    console.log('Task di BackgroundFetch avviato');

    // Richiedi permessi di localizzazione
    const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
    if (locationStatus !== 'granted') {
      console.error('Permesso di localizzazione non concesso');
      BackgroundFetch.finish();
      return;
    }

    // Ottieni la posizione
    const location = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.High,
      timeout: 10000,
    });

    const { latitude, longitude } = location.coords;
    const currentTime = new Date().toLocaleTimeString();

    console.log('Posizione ottenuta:', latitude, longitude);
    console.log('Ora attuale:', currentTime);

    //await sendNotification(latitude, longitude, currentTime);

    BackgroundFetch.finish(BackgroundFetch.BackgroundFetchResult.NewData);
  } catch (error) {
    console.error('Errore durante BackgroundFetch:', error);
    BackgroundFetch.finish(BackgroundFetch.BackgroundFetchResult.Failed);
  }
});

// Funzione per inviare notifiche
const sendNotification = async (latitude, longitude, currentTime) => {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'Nuove coordinate!',
      body: `Latitudine: ${latitude.toFixed(6)}, Longitudine: ${longitude.toFixed(6)} alle ${currentTime}`,
      data: { latitude, longitude, time: currentTime },
    },
    trigger: null,
  });
};

// Funzione per registrare le notifiche push
async function registerForPushNotificationsAsync() {
  let token;
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    //Alert.alert('Failed to get push token for push notification!');
    return;
  }

  token = (await Notifications.getExpoPushTokenAsync()).data;
  //Alert.alert('Push Token:', token);
  console.log(token);

  return token;
}

// App principale
export default function App() {
  const [expoPushToken, setExpoPushToken] = useState('');
  const [location, setLocation] = useState(null);
  const [time, setTime] = useState(null);
  const [isOnline, setIsOnline] = useState(false);

  useEffect(() => {
    // Richiedi permessi per le notifiche e la geolocalizzazione
    requestNotificationPermission();
    requestLocationPermission();

    // Funzione per registrare il task di background fetch
    const registerTask = async () => {
      try {
        await BackgroundFetch.registerTaskAsync(BACKGROUND_FETCH_TASK, {
          minimumInterval: 1, // Intervallo minimo di 15 minuti
          stopOnTerminate: false,
          startOnBoot: true,
        });
        //Alert.alert('Task di background registrato con successo');
      } catch (error) {
        //Alert.alert('Errore nella registrazione del task', error.message);
      }
    };

    const configureBackgroundFetch = async () => {
      if (isOnline) {
        await registerTask();
      } else {
        console.log('BackgroundFetch disabilitato');
        // Potresti voler disregistrare il task quando si va offline, ma solo se necessario
      }
    };

    configureBackgroundFetch();

    return () => {
      if (isOnline) {
        console.log('App dismontata, BackgroundFetch non gestito sul web');
        // Pulizia all'unmount
        // Non disregistrare su web
      }
    };
  }, [isOnline]);

  useEffect(() => {
    const subscription = Notifications.addNotificationReceivedListener(notification => {
      const { title, body } = notification.request.content;
      Alert.alert(title, body);
    });

    return () => subscription.remove();
  }, []);

  const requestNotificationPermission = async () => {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permesso per le notifiche non concesso');
    } else {
      const token = await registerForPushNotificationsAsync();
      setExpoPushToken(token);
      console.log('Push Token:', token);
      //Alert.alert('Push Token:', token);
    }
  };

  const requestLocationPermission = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permesso per la geolocalizzazione non concesso');
    }
  };

  const updateLocation = async () => {
    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      const { latitude, longitude } = location.coords;
      const currentTime = new Date().toLocaleTimeString();

      setLocation({ latitude, longitude });
      setTime(currentTime);

      if (expoPushToken) {
        //await sendNotification(latitude, longitude, currentTime);
      }
    } catch (error) {
      //Alert.alert('Errore nella geolocalizzazione', error.message);
    }
  };

  useEffect(() => {
    let intervalId;
    if (isOnline) {
      updateLocation();
      intervalId = setInterval(updateLocation, 60000); // Aggiorna ogni minuto
    } else {
      clearInterval(intervalId);
    }
    return () => clearInterval(intervalId);
  }, [isOnline]);

  const toggleOnlineStatus = () => {
    setIsOnline(prev => !prev);
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Ora corrente: {time || 'Calcolo...'}</Text>
      <Text>Latitudine: {location?.latitude?.toString() || 'Calcolo...'}</Text>
      <Text>Longitudine: {location?.longitude?.toString() || 'Calcolo...'}</Text>
      <Button
        title={isOnline ? 'Vai Offline' : 'Vai Online'}
        onPress={toggleOnlineStatus}
      />
    </View>
  );
}
*/
/*
import React, { useEffect, useState } from 'react';
import { Text, View, Button, Alert, StyleSheet, Dimensions } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Location from 'expo-location';
import * as BackgroundFetch from 'expo-background-fetch';
import * as TaskManager from 'expo-task-manager';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { WebView } from 'react-native-webview';

// Define the name of the background fetch task
const BACKGROUND_FETCH_TASK = 'background-fetch-task';

// Configure notifications
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

// Define the background fetch task
TaskManager.defineTask(BACKGROUND_FETCH_TASK, async () => {
  try {
    console.log('Background fetch task started');

    // Request location permissions
    const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
    if (locationStatus !== 'granted') {
      console.error('Location permission not granted');
      BackgroundFetch.finish();
      return;
    }

    // Get location
    const location = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.High,
      timeout: 10000,
    });

    const { latitude, longitude } = location.coords;
    const currentTime = new Date().toLocaleTimeString();

    console.log('Location obtained:', latitude, longitude);
    console.log('Current time:', currentTime);

    // Optionally send a notification here
    // await sendNotification(latitude, longitude, currentTime);

    BackgroundFetch.finish(BackgroundFetch.BackgroundFetchResult.NewData);
  } catch (error) {
    console.error('Error during background fetch:', error);
    BackgroundFetch.finish(BackgroundFetch.BackgroundFetchResult.Failed);
  }
});

// Function to send notifications
const sendNotification = async (latitude, longitude, currentTime) => {
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'New coordinates!',
      body: `Latitude: ${latitude.toFixed(6)}, Longitude: ${longitude.toFixed(6)} at ${currentTime}`,
      data: { latitude, longitude, time: currentTime },
    },
    trigger: null,
  });
};

// Function to register for push notifications
async function registerForPushNotificationsAsync() {
  let token;
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    return;
  }

  token = (await Notifications.getExpoPushTokenAsync()).data;
  console.log(token);

  return token;
}

// Define screens
function HomeScreen() {
  const [location, setLocation] = useState(null);
  const [time, setTime] = useState(null);
  const [isOnline, setIsOnline] = useState(false);
  const [expoPushToken, setExpoPushToken] = useState('');

  useEffect(() => {
    const requestPermissions = async () => {
      const { status: notificationStatus } = await Notifications.requestPermissionsAsync();
      if (notificationStatus !== 'granted') {
        //Alert.alert('Notification permission not granted');
        return;
      }

      const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
      if (locationStatus !== 'granted') {
        //Alert.alert('Location permission not granted');
        return;
      }

      //Alert.alert('Permissions granted', 'All permissions have been granted.');
    };

    const registerTask = async () => {
      try {
        await BackgroundFetch.registerTaskAsync(BACKGROUND_FETCH_TASK, {
          minimumInterval: 1, // Minimum interval of 1 minute for testing
          stopOnTerminate: false,
          startOnBoot: true,
        });
        //Alert.alert('Background task registered successfully');
      } catch (error) {
        //Alert.alert('Error registering task', error.message);
      }
    };

    const configureBackgroundFetch = async () => {
      if (isOnline) {
        await registerTask();
      } else {
        console.log('BackgroundFetch disabled');
      }
    };

    requestPermissions();
    configureBackgroundFetch();

    return () => {
      if (isOnline) {
        console.log('App unmounted, BackgroundFetch not handled on web');
      }
    };
  }, [isOnline]);

  useEffect(() => {
    const subscription = Notifications.addNotificationReceivedListener(notification => {
      const { title, body } = notification.request.content;
      Alert.alert(title, body);
    });

    return () => subscription.remove();
  }, []);

  const updateLocation = async () => {
    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      const { latitude, longitude } = location.coords;
      const currentTime = new Date().toLocaleTimeString();

      setLocation({ latitude, longitude });
      setTime(currentTime);

      if (expoPushToken) {
        // await sendNotification(latitude, longitude, currentTime);
      }
    } catch (error) {
      // Alert.alert('Error obtaining location', error.message);
    }
  };

  useEffect(() => {
    let intervalId;
    if (isOnline) {
      updateLocation();
      intervalId = setInterval(updateLocation, 60000); // Update every minute
    } else {
      clearInterval(intervalId);
    }
    return () => clearInterval(intervalId);
  }, [isOnline]);

  const toggleOnlineStatus = () => {
    setIsOnline(prev => !prev);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Ora corrente: {time || 'Calcolo...'}</Text>
      <Text style={styles.text}>Latitudine: {location?.latitude?.toString() || 'Calcolo...'}</Text>
      <Text style={styles.text}>Longitudine: {location?.longitude?.toString() || 'Calcolo...'}</Text>
      <Button
        title={isOnline ? 'Vai Offline' : 'Vai Online'}
        onPress={toggleOnlineStatus}
      />
    </View>
  );
}




function ProfileScreen() {
  return (
    <View style={style.container}>
      <WebView
        source={{ uri: 'https://booking.tuttotransfercalabria.net/sito/corse_autista.php?tk=JKSHKAshdyDIU389Y98hjkhhsuih89dad8378gdwjkdhaudhqd837dgq9x3g938983dyhauhdasdhauishduihasudhad839d9833893hxiauhxaoxiaou38hHIOHIHIIHOIYY8Y989YDHEW&na=393455166806' }}
        style={{ flex: 1 }}
      />
    </View>
  );
}

const style = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    // Optional: add padding if needed
    padding: 10,
  },
  webview: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
  },
});


function SettingsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Settings Screen</Text>
    </View>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;
            if (route.name === 'Home') {
              iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === 'Profile') {
              iconName = focused ? 'person' : 'person-outline';
            } else if (route.name === 'Settings') {
              iconName = focused ? 'settings' : 'settings-outline';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: 'tomato',
          tabBarInactiveTintColor: 'gray',
        })}
      >
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Profile" component={ProfileScreen} />
        <Tab.Screen name="Settings" component={SettingsScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 24,
  },
});

*/
/*
import React, { useEffect, useState } from 'react';
import { Text, View, Button, Alert, StyleSheet, Dimensions } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Location from 'expo-location';
import * as BackgroundFetch from 'expo-background-fetch';
import * as TaskManager from 'expo-task-manager';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { WebView } from 'react-native-webview';

// Define the name of the background fetch task
const BACKGROUND_FETCH_TASK = 'background-fetch-task';

// Configure notifications
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

// Define the background fetch task
TaskManager.defineTask(BACKGROUND_FETCH_TASK, async () => {
  try {
    console.log('Background fetch task started');

    // Request location permissions
    const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
    if (locationStatus !== 'granted') {
      console.error('Location permission not granted');
      BackgroundFetch.finish();
      return;
    }

    // Get location
    const location = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.High,
      timeout: 10000,
    });

    const { latitude, longitude } = location.coords;
    const currentTime = new Date().toLocaleTimeString();

    console.log('Location obtained:', latitude, longitude);
    console.log('Current time:', currentTime);

    // Optionally send a notification here
    // await sendNotification(latitude, longitude, currentTime);

    BackgroundFetch.finish(BackgroundFetch.BackgroundFetchResult.NewData);
  } catch (error) {
    console.error('Error during background fetch:', error);
    BackgroundFetch.finish(BackgroundFetch.BackgroundFetchResult.Failed);
  }
});

// Function to send notifications
const sendNotification = async (latitude, longitude, currentTime) => {
  
  await Notifications.scheduleNotificationAsync({
    content: {
      title: 'New coordinates!',
      body: `Latitude: ${latitude.toFixed(6)}, Longitude: ${longitude.toFixed(6)} at ${currentTime}`,
      data: { latitude, longitude, time: currentTime },
    },
    trigger: null,
  });
};

// Function to register for push notifications
async function registerForPushNotificationsAsync() {
  let token;
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    return;
  }

  token = (await Notifications.getExpoPushTokenAsync()).data;
  console.log(token);

  return token;
}

// Define screens
function HomeScreen() {
  const [location, setLocation] = useState(null);
  const [time, setTime] = useState(null);
  const [isOnline, setIsOnline] = useState(false);
  const [expoPushToken, setExpoPushToken] = useState('');

  useEffect(() => {
    const requestPermissions = async () => {
      const { status: notificationStatus } = await Notifications.requestPermissionsAsync();
      if (notificationStatus !== 'granted') {
        //Alert.alert('Notification permission not granted');
        return;
      }

      const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
      if (locationStatus !== 'granted') {
        //Alert.alert('Location permission not granted');
        return;
      }

      //Alert.alert('Permissions granted', 'All permissions have been granted.');
    };

    const registerTask = async () => {
      try {
        await BackgroundFetch.registerTaskAsync(BACKGROUND_FETCH_TASK, {
          minimumInterval: 1, // Minimum interval of 1 minute for testing
          stopOnTerminate: false,
          startOnBoot: true,
        });
        //Alert.alert('Background task registered successfully');
      } catch (error) {
        //Alert.alert('Error registering task', error.message);
      }
    };

    const configureBackgroundFetch = async () => {
      if (isOnline) {
        await registerTask();
      } else {
        console.log('BackgroundFetch disabled');
      }
    };

    requestPermissions();
    configureBackgroundFetch();

    return () => {
      if (isOnline) {
        console.log('App unmounted, BackgroundFetch not handled on web');
      }
    };
  }, [isOnline]);

  useEffect(() => {
    const subscription = Notifications.addNotificationReceivedListener(notification => {
      const { title, body } = notification.request.content;
      Alert.alert(title, body);
    });

    return () => subscription.remove();
  }, []);

// Function to send coordinates to server
const sendCoordinatesToServer = async (latitude, longitude, currentTime) => {
  try {
    const response = await fetch('https://booking.tuttotransfercalabria.net/sito/ricevi.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        dataOra: currentTime,
        latitudine: latitude.toFixed(6),
        longitudine: longitude.toFixed(6),
      }).toString(),
    });

    if (!response.ok) {
      throw new Error('Network response was not ok.');
    }

    console.log('Coordinates sent successfully');
  } catch (error) {
    console.error('Error sending coordinates to server:', error);
  }
};

  const updateLocation = async () => {
    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      const { latitude, longitude } = location.coords;
      const currentTime = new Date().toLocaleTimeString();

      setLocation({ latitude, longitude });
      setTime(currentTime);

      if (expoPushToken) {
        // await sendNotification(latitude, longitude, currentTime);
      }
      if (isOnline) {
        await sendCoordinatesToServer(latitude, longitude, currentTime);
      }
    } catch (error) {
      // Alert.alert('Error obtaining location', error.message);
    }
  };

  useEffect(() => {
    let intervalId;
    if (isOnline) {
      updateLocation();
      intervalId = setInterval(updateLocation, 60000); // Update every minute
    } else {
      clearInterval(intervalId);
    }
    return () => clearInterval(intervalId);
  }, [isOnline]);

  const toggleOnlineStatus = () => {
    setIsOnline(prev => !prev);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Ora corrente: {time || 'Calcolo...'}</Text>
      <Text style={styles.text}>Latitudine: {location?.latitude?.toString() || 'Calcolo...'}</Text>
      <Text style={styles.text}>Longitudine: {location?.longitude?.toString() || 'Calcolo...'}</Text>
      <Button
        title={isOnline ? 'Vai Offline' : 'Vai Online'}
        onPress={toggleOnlineStatus}
      />
    </View>
  );
}

function ProfileScreen() {
  return (
    <View style={styles.webviewContainer}>
      <WebView
        source={{ uri: 'https://booking.tuttotransfercalabria.net/sito/corse_autista.php?tk=JKSHKAshdyDIU389Y98hjkhhsuih89dad8378gdwjkdhaudhqd837dgq9x3g938983dyhauhdasdhauishduihasudhad839d9833893hxiauhxaoxiaou38hHIOHIHIIHOIYY8Y989YDHEW&na=393455166806' }}
        style={styles.webview}
      />
    </View>
  );
}

function SettingsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Settings Screen</Text>
    </View>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
        <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;
            if (route.name === 'Vai Online') {
              iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === 'Servizi') {
              iconName = focused ? 'person' : 'person-outline';
            } else if (route.name === 'Settings') {
              iconName = focused ? 'settings' : 'settings-outline';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: 'tomato',
          tabBarInactiveTintColor: 'gray',
          headerShown: false, // Nasconde la barra del titolo sopra la schermata
        })}
      >
        <Tab.Screen name="Vai Online" component={HomeScreen} />
        <Tab.Screen name="Servizi" component={ProfileScreen} />
        <Tab.Screen name="Settings" component={SettingsScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 24,
  },
  webviewContainer: {
    flex: 1,
  },
  webview: {
    flex: 1,
  },
});
*/
import React, { useEffect, useState } from 'react';
import { Text, View, Button, Alert, StyleSheet, Dimensions } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Location from 'expo-location';
import * as BackgroundFetch from 'expo-background-fetch';
import * as TaskManager from 'expo-task-manager';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { WebView } from 'react-native-webview';

// Define the name of the background fetch task
const BACKGROUND_FETCH_TASK = 'background-fetch-task';

// Configure notifications
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

// Define the background fetch task
TaskManager.defineTask(BACKGROUND_FETCH_TASK, async () => {
  try {
    console.log('Background fetch task started');

    // Request location permissions
    const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
    if (locationStatus !== 'granted') {
      console.error('Location permission not granted');
      BackgroundFetch.finish();
      return;
    }

    // Get location
    const location = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.High,
      timeout: 10000,
    });

    const { latitude, longitude } = location.coords;
    const currentTime = new Date().toISOString(); // Use ISO string for better formatting

    console.log('Location obtained:', latitude, longitude);
    console.log('Current time:', currentTime);

    // Send location data to server
    await sendCoordinatesToServer(latitude, longitude, currentTime);

    BackgroundFetch.finish(BackgroundFetch.BackgroundFetchResult.NewData);
  } catch (error) {
    console.error('Error during background fetch:', error);
    BackgroundFetch.finish(BackgroundFetch.BackgroundFetchResult.Failed);
  }
});

// Function to send coordinates to your server
const sendCoordinatesToServer = async (latitude, longitude, currentTime) => {
  try {
    const response = await fetch('https://booking.tuttotransfercalabria.net/sito/ricevi.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        dataOra: currentTime,
        latitudine: latitude.toFixed(6),
        longitudine: longitude.toFixed(6),
      }).toString(),
    });

    if (!response.ok) {
      throw new Error('Network response was not ok.');
    }

    console.log('Coordinates sent successfully');
  } catch (error) {
    console.error('Error sending coordinates to server:', error);
  }
};

// Function to register for push notifications
async function registerForPushNotificationsAsync() {
  let token;
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    return;
  }

  token = (await Notifications.getExpoPushTokenAsync()).data;
  console.log(token);

  return token;
}

// Define screens
function HomeScreen() {
  const [location, setLocation] = useState(null);
  const [time, setTime] = useState(null);
  const [isOnline, setIsOnline] = useState(false);
  const [expoPushToken, setExpoPushToken] = useState('');

  useEffect(() => {
    const requestPermissions = async () => {
      const { status: notificationStatus } = await Notifications.requestPermissionsAsync();
      if (notificationStatus !== 'granted') {
        return;
      }

      const { status: locationStatus } = await Location.requestForegroundPermissionsAsync();
      if (locationStatus !== 'granted') {
        return;
      }
    };

    const registerTask = async () => {
      try {
        await BackgroundFetch.registerTaskAsync(BACKGROUND_FETCH_TASK, {
          minimumInterval: 1 * 60, // Minimum interval of 15 minutes for production
          stopOnTerminate: false,
          startOnBoot: true,
        });
        console.log('Background task registered successfully');
      } catch (error) {
        console.error('Error registering task:', error);
      }
    };

    const configureBackgroundFetch = async () => {
      if (isOnline) {
        await registerTask();
      } else {
        console.log('BackgroundFetch disabled');
      }
    };

    requestPermissions();
    configureBackgroundFetch();

    return () => {
      if (isOnline) {
        BackgroundFetch.unregisterTaskAsync(BACKGROUND_FETCH_TASK);
        console.log('Background task unregistered');
      }
    };
  }, [isOnline]);

  useEffect(() => {
    const subscription = Notifications.addNotificationReceivedListener(notification => {
      const { title, body } = notification.request.content;
      Alert.alert(title, body);
    });

    return () => subscription.remove();
  }, []);

  const updateLocation = async () => {
    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.High,
      });
      const { latitude, longitude } = location.coords;
      const currentTime = new Date().toISOString(); // Use ISO string for better formatting

      setLocation({ latitude, longitude });
      setTime(currentTime);

      if (expoPushToken) {
        // await sendNotification(latitude, longitude, currentTime);
      }
      if (isOnline) {
        await sendCoordinatesToServer(latitude, longitude, currentTime);
      }
    } catch (error) {
      console.error('Error obtaining location:', error);
    }
  };

  useEffect(() => {
    let intervalId;
    if (isOnline) {
      updateLocation();
      intervalId = setInterval(updateLocation, 60000); // Update every minute
    } else {
      clearInterval(intervalId);
    }
    return () => clearInterval(intervalId);
  }, [isOnline]);

  const toggleOnlineStatus = () => {
    setIsOnline(prev => !prev);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Ora corrente: {time || 'Calcolo...'}</Text>
      <Text style={styles.text}>Latitudine: {location?.latitude?.toString() || 'Calcolo...'}</Text>
      <Text style={styles.text}>Longitudine: {location?.longitude?.toString() || 'Calcolo...'}</Text>
      <Button
        title={isOnline ? 'Vai Offline' : 'Vai Online'}
        onPress={toggleOnlineStatus}
      />
    </View>
  );
}

function ProfileScreen() {
  return (
    <View style={styles.webviewContainer}>
      <WebView
        source={{ uri: 'https://booking.tuttotransfercalabria.net/sito/corse_autista.php?tk=JKSHKAshdyDIU389Y98hjkhhsuih89dad8378gdwjkdhaudhqd837dgq9x3g938983dyhauhdasdhauishduihasudhad839d9833893hxiauhxaoxiaou38hHIOHIHIIHOIYY8Y989YDHEW&na=393455166806' }}
        style={styles.webview}
      />
    </View>
  );
}

function SettingsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Settings Screen</Text>
    </View>
  );
}

const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ focused, color, size }) => {
            let iconName;
            if (route.name === 'Vai Online') {
              iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === 'Servizi') {
              iconName = focused ? 'person' : 'person-outline';
            } else if (route.name === 'Settings') {
              iconName = focused ? 'settings' : 'settings-outline';
            }

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: 'tomato',
          tabBarInactiveTintColor: 'gray',
          headerShown: false, // Nasconde la barra del titolo sopra la schermata
        })}
      >
        <Tab.Screen name="Vai Online" component={HomeScreen} />
        <Tab.Screen name="Servizi" component={ProfileScreen} />
        <Tab.Screen name="Settings" component={SettingsScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    fontSize: 24,
  },
  webviewContainer: {
    flex: 1,
  },
  webview: {
    flex: 1,
  },
});
